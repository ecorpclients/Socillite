const DIV = document.querySelector('div');

const SPLASHSCREEN = () => {

    DIV.innerHTML = `

        <img class='SplashScreenImage' src='socie 512.jpg'/>

    `;

    setTimeout(() => {

        import("https://ecorpclients.github.io/Socillite/CONNECTION/Connection.js").then((module) => {
            
            const { CONNECTION } = module;

            if (navigator.onLine) {

                CONNECTION(DIV);
            }

        });

    }, 2000);
    
};

SPLASHSCREEN();
